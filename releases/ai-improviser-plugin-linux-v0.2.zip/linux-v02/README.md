Linux users hello

Put the vst3 folder in your ~/.vst3 folder
Or run the standalone app

If not working, try a build from source, from top level folder:

cmake -B build .
cmake --build build --config Release -j 6
