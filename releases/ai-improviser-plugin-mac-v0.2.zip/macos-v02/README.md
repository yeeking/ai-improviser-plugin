Built as universal binary for macOS 11 and later

* Quit the VST host if it is running [logic/ etc.]
* Copy the .vst file to this folder: /Library/Audio/Plug-Ins/VST3
* Open a terminal and run this command, which will allow unsigned software to run: 

```
sudo spctl --master-disable
```

* Launch your VST host and let it scan 
* Verify you add the ai-improviser plugin to your host
* Run this command in the terminal to re-enable blocking of unsigned software:

```
sudo spctl --master-enable
```

