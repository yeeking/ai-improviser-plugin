* Copy the .vst file to C:\Program Files\Common Files\VST3
* Your host should scan and find it
